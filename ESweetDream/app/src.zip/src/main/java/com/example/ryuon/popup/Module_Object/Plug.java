package com.example.ryuon.popup.Module_Object;

public class Plug extends module {
    String temperature;
    String humidity;
    String power_1; // 플러그1 전원
    String power_2; // 플러그2 전원
}
