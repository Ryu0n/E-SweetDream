package com.example.ryuon.popup.AutoControl;

import androidx.appcompat.app.AppCompatActivity;

public class AutoPlugActivity extends AppCompatActivity implements AutoControl  {
}
