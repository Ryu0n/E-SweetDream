package com.example.ryuon.popup.Module_Object;

public class Lamp extends module{


    String send_Info;
    // Send_Info에 병합

    String weather;
    String sleep_Time;
    String sleep_Hour;
    String sleep_Min;
    String color;
    String power; // 전원
}
