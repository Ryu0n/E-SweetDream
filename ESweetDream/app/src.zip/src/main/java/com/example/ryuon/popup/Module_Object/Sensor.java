package com.example.ryuon.popup.Module_Object;

public class Sensor extends module{

}
