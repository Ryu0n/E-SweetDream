package com.example.ryuon.popup.AutoControl;

import androidx.appcompat.app.AppCompatActivity;

public class AutoLampActivity extends AppCompatActivity implements AutoControl  {
}
