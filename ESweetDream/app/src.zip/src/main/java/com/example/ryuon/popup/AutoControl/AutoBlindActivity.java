package com.example.ryuon.popup.AutoControl;

import androidx.appcompat.app.AppCompatActivity;

public class AutoBlindActivity extends AppCompatActivity {


}
