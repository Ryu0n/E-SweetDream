package com.example.ryuon.popup.Module_Object;

public class Blind extends module {
    boolean upDown;
    float degree;
    float lux;
}
