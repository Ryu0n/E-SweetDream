package com.example.ryuon.popup.AutoControl;

public interface AutoControl{
}
