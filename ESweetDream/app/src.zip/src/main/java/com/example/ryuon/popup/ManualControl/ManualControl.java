package com.example.ryuon.popup.ManualControl;

public interface ManualControl{
}
