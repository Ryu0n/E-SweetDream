package com.example.ryuon.popup.Bluetooth;

import com.example.ryuon.popup.Activity.GroupEditingActivity_new;
import com.example.ryuon.popup.Module_Object.Group;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.util.Log;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class BluetoothHelper implements Serializable {
    private static Set<BluetoothDevice> devices; // 블루투스 디바이스 데이터 셋
    private BluetoothAdapter bluetoothAdapter; // 블루투스 어댑터

    public ArrayList<BluetoothSocket> bluetoothSockets;
    ArrayList<OutputStream> outputStreams;
    ArrayList<InputStream> inputStreams;

    public BluetoothHelper() {
        // 블루투스 활성화하기
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter(); // 블루투스 어댑터를 디폴트 어댑터로 설정

        if(bluetoothAdapter == null) { // 디바이스가 블루투스를 지원하지 않을 때
            // 여기에 처리 할 코드를 작성하세요.
        } else { // 디바이스가 블루투스를 지원 할 때
            if(bluetoothAdapter.isEnabled()) { // 블루투스가 활성화 상태 (기기에 블루투스가 켜져있음)
                GroupEditingActivity_new.setModuleList(selectBluetoothDevice()); // 블루투스 디바이스 선택 함수 호출
            }
        }
    }

    public ArrayList<String> selectBluetoothDevice() {
        // 이미 페어링 되어있는 블루투스 기기를 찾습니다.
        devices = bluetoothAdapter.getBondedDevices();
        ArrayList<String> moduleList = new ArrayList<>();
        // 페어링 된 디바이스의 크기를 저장
        int pariedDeviceCount = devices.size();
        // 페어링 되어있는 장치가 없는 경우
        if (pariedDeviceCount == 0) {
            // 페어링을 하기위한 함수 호출
        } else {
            // 페어링된 디바이스중에서 E편한꿀잠에 관련된 모듈의 이름을 리스트에 추가
            for (BluetoothDevice bluetoothDevice : devices) {
                if (bluetoothDevice.getName().contains("ESD0-")) {
                    moduleList.add(bluetoothDevice.getName());
                }
            }
        }
        return moduleList;
    }

    public void connectDevice(ArrayList deviceNames) {
        ArrayList<BluetoothDevice> bluetoothDevices = new ArrayList<>();
        bluetoothSockets = new ArrayList<>();
        outputStreams = new ArrayList<>();
        inputStreams = new ArrayList<>();

        for(BluetoothDevice tempDevice : devices) {
            // 사용자가 선택한 이름과 같은 디바이스로 설정하고 반복문 종료
            if(deviceNames.contains(tempDevice.getName())) {
                bluetoothDevices.add(tempDevice);
            }
        }
        // UUID 생성
        UUID uuid = java.util.UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");
        // Rfcomm 채널을 통해 블루투스 디바이스와 통신하는 소켓 생성
        try {
            for (int i = 0; i < bluetoothDevices.size(); i++) {
                bluetoothSockets.add(bluetoothDevices.get(i).createRfcommSocketToServiceRecord(uuid));
                bluetoothSockets.get(i).connect();
                // 데이터 송,수신 스트림을 얻어옵니다.
                outputStreams.add(bluetoothSockets.get(i).getOutputStream());
                inputStreams.add(bluetoothSockets.get(i).getInputStream());
            }
//            // 데이터 수신 함수 호출 - 센서모듈만
//            receiveData();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void disconnectDevice() {
        try {
            for (int i = 0; i < bluetoothSockets.size(); i++) {
                inputStreams.get(i).close();
                outputStreams.get(i).close();
                bluetoothSockets.get(i).close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

//        // 센서모듈만요
//    public void receiveData() {
//        for (int i = 0; i < bluetoothDevices.size(); i ++){
//            if (bluetoothDevices.get(i).getName().contains("ESD0-센서모듈")) {
//
//            }
//        }
//        final Handler handler = new Handler(); // 나중에 안되면 내 책임 - import 둘중 하나 첫번쨰꺼 고름 (android.os)
//        // 데이터를 수신하기 위한 버퍼를 생성
//        readBufferPosition = 0;
//        readBuffer = new byte[1024];
//
//        // 데이터를 수신하기 위한 쓰레드 생성
//        workerThread = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                while(Thread.currentThread().isInterrupted()) {
//                    try {
//                        // 데이터를 수신했는지 확인합니다.
//                        int byteAvailable = inputStream.available();
//                        // 데이터가 수신 된 경우
//                        if(byteAvailable > 0) {
//                            // 입력 스트림에서 바이트 단위로 읽어 옵니다.
//                            byte[] bytes = new byte[byteAvailable];
//                            inputStream.read(bytes);
//                            // 입력 스트림 바이트를 한 바이트씩 읽어 옵니다.
//                            for(int i = 0; i < byteAvailable; i++) {
//                                byte tempByte = bytes[i];
//                                // 개행문자를 기준으로 받음(한줄)
//                                if(tempByte == '\n') {
//                                    // readBuffer 배열을 encodedBytes로 복사
//                                    byte[] encodedBytes = new byte[readBufferPosition];
//                                    System.arraycopy(readBuffer, 0, encodedBytes, 0, encodedBytes.length);
//                                    // 인코딩 된 바이트 배열을 문자열로 변환
//                                    final String text = new String(encodedBytes, "US-ASCII");
//                                    readBufferPosition = 0;
//                                    handler.post(new Runnable() {
//                                        @Override
//                                        public void run() {
//                                            // 텍스트 뷰에 출력
//                                            textViewReceive.append(text + "\n");
//                                        }
//                                    });
//                                } // 개행 문자가 아닐 경우
//                                else {
//                                    readBuffer[readBufferPosition++] = tempByte;
//                                }
//                            }
//                        }
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                    try {
//                        // 1초마다 받아옴
//                        Thread.sleep(1000);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//        });
//        workerThread.start();
//    }
}
